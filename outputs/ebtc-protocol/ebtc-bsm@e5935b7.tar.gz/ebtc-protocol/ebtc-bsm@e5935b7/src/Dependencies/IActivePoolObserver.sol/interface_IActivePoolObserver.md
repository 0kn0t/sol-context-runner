# Interface: IActivePoolObserver

## Metadata

- **Name**: IActivePoolObserver
- **Type**: Interface
- **Path**: src/Dependencies/IActivePoolObserver.sol

## Public/External Functions

### observe()

- **Signature**: `observe()`
- **Visibility**: external
- **Source Range**: 103:51:29

**Signature:**
```solidity
function observe() external view returns (uint256);;
```
