# Contract: Address

## Metadata

- **Name**: Address
- **Type**: Contract
- **Path**: lib/aave-v3-origin/src/contracts/dependencies/openzeppelin/contracts/Address.sol
- **Documentation**:  @dev Collection of functions related to the address type
