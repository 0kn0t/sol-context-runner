# Interface: IInitializableDebtToken

## Metadata

- **Name**: IInitializableDebtToken
- **Type**: Interface
- **Path**: lib/aave-v3-origin/src/contracts/interfaces/IInitializableDebtToken.sol
- **Documentation**:  @title IInitializableDebtToken
   @author Aave
   @notice Interface for the initialize function common between debt tokens

## Events

### Initialized

```solidity
///  @dev Emitted when a debt token is initialized
///  @param underlyingAsset The address of the underlying asset
///  @param pool The address of the associated pool
///  @param incentivesController The address of the incentives controller for this aToken
///  @param debtTokenDecimals The decimals of the debt token
///  @param debtTokenName The name of the debt token
///  @param debtTokenSymbol The symbol of the debt token
///  @param params A set of encoded parameters for additional initialization
event Initialized(address indexed underlyingAsset, address indexed pool, address incentivesController, uint8 debtTokenDecimals, string debtTokenName, string debtTokenSymbol, bytes params);
```

## Public/External Functions

### initialize(contract IPool,address,contract IAaveIncentivesController,uint8,string,string,bytes)

- **Signature**: `initialize(contract IPool,address,contract IAaveIncentivesController,uint8,string,string,bytes)`
- **Visibility**: external
- **Source Range**: 1669:254:17

**Signature:**
```solidity
///  @notice Initializes the debt token.
///  @param pool The pool contract that is initializing this contract
///  @param underlyingAsset The address of the underlying asset of this aToken (E.g. WETH for aWETH)
///  @param incentivesController The smart contract managing potential incentives distribution
///  @param debtTokenDecimals The decimals of the debtToken, same as the underlying asset's
///  @param debtTokenName The name of the token
///  @param debtTokenSymbol The symbol of the token
///  @param params A set of encoded parameters for additional initialization
function initialize(IPool pool, address underlyingAsset, IAaveIncentivesController incentivesController, uint8 debtTokenDecimals, string memory debtTokenName, string memory debtTokenSymbol, bytes calldata params) external;;
```
