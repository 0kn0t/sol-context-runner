# Contract: Comparators

## Metadata

- **Name**: Comparators
- **Type**: Contract
- **Path**: lib/openzeppelin-contracts/contracts/utils/Comparators.sol
- **Documentation**:  @dev Provides a set of functions to compare values.
   _Available since v5.1._
