# Contract: SignedMath

## Metadata

- **Name**: SignedMath
- **Type**: Contract
- **Path**: lib/openzeppelin-contracts/contracts/utils/math/SignedMath.sol
- **Documentation**:  @dev Standard signed math utilities missing in the Solidity language.
