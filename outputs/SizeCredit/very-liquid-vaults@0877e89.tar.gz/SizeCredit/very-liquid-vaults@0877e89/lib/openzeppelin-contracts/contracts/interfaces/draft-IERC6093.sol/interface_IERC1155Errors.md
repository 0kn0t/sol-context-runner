# Interface: IERC1155Errors

## Metadata

- **Name**: IERC1155Errors
- **Type**: Interface
- **Path**: lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol
- **Documentation**:  @dev Standard ERC-1155 Errors
   Interface of the https://eips.ethereum.org/EIPS/eip-6093[ERC-6093] custom errors for ERC-1155 tokens.

## Errors

### ERC1155InsufficientBalance

```solidity
///  @dev Indicates an error related to the current `balance` of a `sender`. Used in transfers.
///  @param sender Address whose tokens are being transferred.
///  @param balance Current balance for the interacting account.
///  @param needed Minimum amount required to perform a transfer.
///  @param tokenId Identifier number of a token.
error ERC1155InsufficientBalance(address sender, uint256 balance, uint256 needed, uint256 tokenId);
```

### ERC1155InvalidSender

```solidity
///  @dev Indicates a failure with the token `sender`. Used in transfers.
///  @param sender Address whose tokens are being transferred.
error ERC1155InvalidSender(address sender);
```

### ERC1155InvalidReceiver

```solidity
///  @dev Indicates a failure with the token `receiver`. Used in transfers.
///  @param receiver Address to which tokens are being transferred.
error ERC1155InvalidReceiver(address receiver);
```

### ERC1155MissingApprovalForAll

```solidity
///  @dev Indicates a failure with the `operator`’s approval. Used in transfers.
///  @param operator Address that may be allowed to operate on tokens without being their owner.
///  @param owner Address of the current owner of a token.
error ERC1155MissingApprovalForAll(address operator, address owner);
```

### ERC1155InvalidApprover

```solidity
///  @dev Indicates a failure with the `approver` of a token to be approved. Used in approvals.
///  @param approver Address initiating an approval operation.
error ERC1155InvalidApprover(address approver);
```

### ERC1155InvalidOperator

```solidity
///  @dev Indicates a failure with the `operator` to be approved. Used in approvals.
///  @param operator Address that may be allowed to operate on tokens without being their owner.
error ERC1155InvalidOperator(address operator);
```

### ERC1155InvalidArrayLength

```solidity
///  @dev Indicates an array length mismatch between ids and values in a safeBatchTransferFrom operation.
///  Used in batch transfers.
///  @param idsLength Length of the array of token identifiers
///  @param valuesLength Length of the array of token amounts
error ERC1155InvalidArrayLength(uint256 idsLength, uint256 valuesLength);
```
