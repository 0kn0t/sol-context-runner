# Interface: IScaledBalanceToken

## Metadata

- **Name**: IScaledBalanceToken
- **Type**: Interface
- **Path**: lib/aave-v3-origin/src/contracts/interfaces/IScaledBalanceToken.sol
- **Documentation**:  @title IScaledBalanceToken
   @author Aave
   @notice Defines the basic interface for a scaled-balance token.

## Events

### Mint

```solidity
///  @dev Emitted after the mint action
///  @param caller The address performing the mint
///  @param onBehalfOf The address of the user that will receive the minted tokens
///  @param value The scaled-up amount being minted (based on user entered amount and balance increase from interest)
///  @param balanceIncrease The increase in scaled-up balance since the last action of 'onBehalfOf'
///  @param index The next liquidity index of the reserve
event Mint(address indexed caller, address indexed onBehalfOf, uint256 value, uint256 balanceIncrease, uint256 index);
```

### Burn

```solidity
///  @dev Emitted after the burn action
///  @dev If the burn function does not involve a transfer of the underlying asset, the target defaults to zero address
///  @param from The address from which the tokens will be burned
///  @param target The address that will receive the underlying, if any
///  @param value The scaled-up amount being burned (user entered amount - balance increase from interest)
///  @param balanceIncrease The increase in scaled-up balance since the last action of 'from'
///  @param index The next liquidity index of the reserve
event Burn(address indexed from, address indexed target, uint256 value, uint256 balanceIncrease, uint256 index);
```

## Public/External Functions

### scaledBalanceOf(address)

- **Signature**: `scaledBalanceOf(address)`
- **Visibility**: external
- **Source Range**: 1840:71:6

**Signature:**
```solidity
///  @notice Returns the scaled balance of the user.
///  @dev The scaled balance is the sum of all the updated stored balance divided by the reserve's liquidity index
///  at the moment of the update
///  @param user The user whose balance is calculated
///  @return The scaled balance of the user
function scaledBalanceOf(address user) external view returns (uint256);;
```

### getScaledUserBalanceAndSupply(address)

- **Signature**: `getScaledUserBalanceAndSupply(address)`
- **Visibility**: external
- **Source Range**: 2130:94:6

**Signature:**
```solidity
///  @notice Returns the scaled balance of the user and the scaled total supply.
///  @param user The address of the user
///  @return The scaled balance of the user
///  @return The scaled total supply
function getScaledUserBalanceAndSupply(address user) external view returns (uint256, uint256);;
```

### scaledTotalSupply()

- **Signature**: `scaledTotalSupply()`
- **Visibility**: external
- **Source Range**: 2378:61:6

**Signature:**
```solidity
///  @notice Returns the scaled total supply of the scaled balance token. Represents sum(debt/index)
///  @return The scaled total supply
function scaledTotalSupply() external view returns (uint256);;
```

### getPreviousIndex(address)

- **Signature**: `getPreviousIndex(address)`
- **Visibility**: external
- **Source Range**: 2660:72:6

**Signature:**
```solidity
///  @notice Returns last index interest was accrued to the user's balance
///  @param user The address of the user
///  @return The last index interest was accrued to the user's balance, expressed in ray
function getPreviousIndex(address user) external view returns (uint256);;
```
