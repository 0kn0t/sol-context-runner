# Contract: Arrays

## Metadata

- **Name**: Arrays
- **Type**: Contract
- **Path**: lib/openzeppelin-contracts/contracts/utils/Arrays.sol
- **Documentation**:  @dev Collection of functions related to array types.
