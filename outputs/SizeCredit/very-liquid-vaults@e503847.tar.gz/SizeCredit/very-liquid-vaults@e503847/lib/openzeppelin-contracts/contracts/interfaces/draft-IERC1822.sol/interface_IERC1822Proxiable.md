# Interface: IERC1822Proxiable

## Metadata

- **Name**: IERC1822Proxiable
- **Type**: Interface
- **Path**: lib/openzeppelin-contracts/contracts/interfaces/draft-IERC1822.sol
- **Documentation**:  @dev ERC-1822: Universal Upgradeable Proxy Standard (UUPS) documents a method for upgradeability through a simplified
   proxy whose upgrades are fully controlled by the current implementation.

## Public/External Functions

### proxiableUUID()

- **Signature**: `proxiableUUID()`
- **Visibility**: external
- **Source Range**: 821:57:33

**Signature:**
```solidity
///  @dev Returns the storage slot that the proxiable contract assumes is being used to store the implementation
///  address.
///  IMPORTANT: A proxy pointing at a proxiable contract should not be considered proxiable itself, because this risks
///  bricking a proxy that upgrades to it, by delegating to itself until out of gas. Thus it is critical that this
///  function revert if invoked through a proxy.
function proxiableUUID() external view returns (bytes32);;
```
