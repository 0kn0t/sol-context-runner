# Interface: IERC20

## Metadata

- **Name**: IERC20
- **Type**: Interface
- **Path**: src/interfaces/IERC20.sol
- **Documentation**: @title IERC20
   @author Morpho Labs
   @custom:contact security@morpho.org
   @dev Empty because we only call library functions. It prevents calling transfer (transferFrom) instead of
   safeTransfer (safeTransferFrom).
