# Contract: UtilsLib

## Metadata

- **Name**: UtilsLib
- **Type**: Contract
- **Path**: src/libraries/UtilsLib.sol
- **Documentation**: @title UtilsLib
   @author Morpho Labs
   @custom:contact security@morpho.org
   @notice Library exposing helpers.
   @dev Inspired by https://github.com/morpho-org/morpho-utils.
