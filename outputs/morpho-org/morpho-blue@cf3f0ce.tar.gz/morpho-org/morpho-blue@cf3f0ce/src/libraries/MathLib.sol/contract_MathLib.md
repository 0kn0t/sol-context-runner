# Contract: MathLib

## Metadata

- **Name**: MathLib
- **Type**: Contract
- **Path**: src/libraries/MathLib.sol
- **Documentation**: @title MathLib
   @author Morpho Labs
   @custom:contact security@morpho.org
   @notice Library to manage fixed-point arithmetic.
