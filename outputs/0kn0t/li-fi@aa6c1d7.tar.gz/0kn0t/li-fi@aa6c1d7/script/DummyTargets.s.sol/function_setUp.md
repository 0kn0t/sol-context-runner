# Function: setUp()

**Contract**: [script/DummyTargets.s.sol/contract_VirtualMachineScript.md]

## Metadata

- **Contract**: VirtualMachineScript
- **Signature**: `setUp()`
- **Visibility**: public
- **Source Range**: 236:26:16

## Implementation

```solidity
function setUp() public {}
```

## Call Tree

```
┌─ [0] ⚙️ FUNCTION: VirtualMachineScript.setUp() (NodeID: 0)
    💬 Args: [no args]
    👁️  Def: public
```
