# Function: setUp()

**Contract**: [script/InvariantCheckerScript.s.sol/contract_InvariantCheckerScript.md]

## Metadata

- **Contract**: InvariantCheckerScript
- **Signature**: `setUp()`
- **Visibility**: public
- **Source Range**: 230:26:18

## Implementation

```solidity
function setUp() public {}
```

## Call Tree

```
┌─ [0] ⚙️ FUNCTION: InvariantCheckerScript.setUp() (NodeID: 0)
    💬 Args: [no args]
    👁️  Def: public
```
