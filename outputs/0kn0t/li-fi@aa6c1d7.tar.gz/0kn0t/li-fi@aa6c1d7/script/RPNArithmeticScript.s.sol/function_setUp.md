# Function: setUp()

**Contract**: [script/RPNArithmeticScript.s.sol/contract_RPNArithmeticScript.md]

## Metadata

- **Contract**: RPNArithmeticScript
- **Signature**: `setUp()`
- **Visibility**: public
- **Source Range**: 227:26:20

## Implementation

```solidity
function setUp() public {}
```

## Call Tree

```
┌─ [0] ⚙️ FUNCTION: RPNArithmeticScript.setUp() (NodeID: 0)
    💬 Args: [no args]
    👁️  Def: public
```
