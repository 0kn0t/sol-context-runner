# Function: setUp()

**Contract**: [script/VirtualMachine.s.sol/contract_DeployVirtualMachine.md]

## Metadata

- **Contract**: DeployVirtualMachine
- **Signature**: `setUp()`
- **Visibility**: public
- **Source Range**: 224:26:21

## Implementation

```solidity
function setUp() public {}
```

## Call Tree

```
┌─ [0] ⚙️ FUNCTION: DeployVirtualMachine.setUp() (NodeID: 0)
    💬 Args: [no args]
    👁️  Def: public
```
