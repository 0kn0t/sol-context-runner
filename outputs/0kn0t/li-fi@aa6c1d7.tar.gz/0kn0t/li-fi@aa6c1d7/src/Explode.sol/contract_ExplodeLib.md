# Contract: ExplodeLib

## Metadata

- **Name**: ExplodeLib
- **Type**: Contract
- **Path**: src/Explode.sol
- **Documentation**: @title Explode Library
   @notice Library for handling the EXPLODE operation in the virtual machine
