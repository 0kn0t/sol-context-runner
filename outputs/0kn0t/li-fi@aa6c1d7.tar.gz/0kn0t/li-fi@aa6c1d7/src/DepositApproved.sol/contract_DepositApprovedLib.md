# Contract: DepositApprovedLib

## Metadata

- **Name**: DepositApprovedLib
- **Type**: Contract
- **Path**: src/DepositApproved.sol
- **Documentation**: @title DepositApproved Library
   @notice Library for handling the DEPOSIT_APPROVED operation in the virtual machine
