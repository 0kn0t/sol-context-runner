# Contract: StandardABI

## Metadata

- **Name**: StandardABI
- **Type**: Contract
- **Path**: src/StandardABI.sol
