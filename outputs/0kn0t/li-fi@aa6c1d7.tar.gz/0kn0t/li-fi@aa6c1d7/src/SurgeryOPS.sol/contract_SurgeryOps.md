# Contract: SurgeryOps

## Metadata

- **Name**: SurgeryOps
- **Type**: Contract
- **Path**: src/SurgeryOPS.sol
- **Documentation**: @title SurgeryOps
   @notice Library for performing byte-level surgery operations on calldata
