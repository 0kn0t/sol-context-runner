# Contract: Mocks

## Metadata

- **Name**: Mocks
- **Type**: Contract
- **Path**: test/lib/Mocks.sol
- **Documentation**: @notice Helper to get EOA-like address.
   @dev Example: address eoa = Mocks.noCode();
