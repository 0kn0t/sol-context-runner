# Contract: console

## Metadata

- **Name**: console
- **Type**: Contract
- **Path**: lib/forge-std/src/console.sol

## State Variables

### CONSOLE_ADDRESS

```solidity
address internal constant CONSOLE_ADDRESS = 0x000000000000000000636F6e736F6c652e6c6f67
```
