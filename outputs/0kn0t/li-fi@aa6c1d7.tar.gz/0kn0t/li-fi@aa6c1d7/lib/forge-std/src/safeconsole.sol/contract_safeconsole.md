# Contract: safeconsole

## Metadata

- **Name**: safeconsole
- **Type**: Contract
- **Path**: lib/forge-std/src/safeconsole.sol
- **Documentation**: @author philogy <https://github.com/philogy>
   @dev Code generated automatically by script.

## State Variables

### CONSOLE_ADDR

```solidity
uint256 internal constant CONSOLE_ADDR = 0x000000000000000000000000000000000000000000636F6e736F6c652e6c6f67
```
